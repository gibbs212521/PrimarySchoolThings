Open file at https://scratch.mit.edu/projects/0/editor/
in Chrome
Press F11 once screen full-size
